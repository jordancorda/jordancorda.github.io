AWAKENINGS — PRESS & BOOKING MATERIALS

This archive contains the English press kit, album cover and three photographs.
Credits and reference links are included in the PDF.
Contact: jaycorda05@gmail.com
